export const Images = [
    {
        id: 1,
        imgName: 'house',
        imgPath: () => require('../../')
    }
]